    <a href="index.php" class="brand-link">
      <span class="logo-mini"><b>G</b>F</span>
      <span class="brand-text font-weight-light">Gully Foyle</span>
    </a>